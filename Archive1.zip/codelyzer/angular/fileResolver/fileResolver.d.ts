export declare abstract class FileResolver {
    abstract resolve(path: string): string;
}
