import { FileResolver } from './fileResolver';
export declare class FsFileResolver extends FileResolver {
    resolve(path: string): string;
}
