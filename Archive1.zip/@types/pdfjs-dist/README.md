# Installation
> `npm install --save @types/pdfjs-dist`

# Summary
This package contains type definitions for PDF.js (https://github.com/mozilla/pdf.js).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/pdfjs-dist

Additional Details
 * Last updated: Thu, 11 Jul 2019 00:11:53 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Josh Baldwin <https://github.com/jbaldwin>, and Dmitrii Sorin <https://github.com/1999>.
