module.exports = function surround(str, wrapper) {
  return [wrapper, str, wrapper].join('');
};
