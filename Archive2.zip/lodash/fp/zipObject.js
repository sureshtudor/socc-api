var convert = require('./convert'),
    func = convert('zipObject', require('../zipObject'));

func.placeholder = require('./placeholder');
module.exports = func;
