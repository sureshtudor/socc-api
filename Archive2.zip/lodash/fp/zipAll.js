var convert = require('./convert'),
    func = convert('zipAll', require('../zip'));

func.placeholder = require('./placeholder');
module.exports = func;
